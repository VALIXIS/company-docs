Set WshShell = CreateObject("WScript.Shell")
' Run START_TAILSCALE_SERVER.bat hidden in background (0 = hide window)
WshShell.Run chr(34) & WshShell.CurrentDirectory & "\START_TAILSCALE_SERVER.bat" & chr(34), 0
Set WshShell = Nothing
