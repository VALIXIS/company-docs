@echo off
title VALIXIS AI Full Autonomous Suite - 24/7 Server
color 0B
cls
echo ==============================================================
echo        VALIXIS AI 24/7 FULL AUTONOMOUS SUITE + CLOUDFLARE TUNNEL
echo ==============================================================
echo.
cd /d "%~dp0"

echo [1/3] Starting Autonomous Outbound Engine & Jarvis Closer...
start /b python lead_engine_daemon.py

echo [2/3] Starting Executive Cockpit Web Server (Port 8000)...
start /b python -m uvicorn server:app --host 0.0.0.0 --port 8000

timeout /t 3 >nul

echo [3/3] Starting Cloudflare Tunnel...
echo.
echo ==============================================================
echo Your web interface is accessible globally via HTTPS.
echo Look for the 'https://*.trycloudflare.com' URL below:
echo ==============================================================
echo.
cloudflared tunnel --url http://localhost:8000
