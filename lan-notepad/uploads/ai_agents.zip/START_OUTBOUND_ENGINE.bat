@echo off
TITLE VALIXIS Outbound Lead Engine & Jarvis System
COLOR 0A

echo =====================================================================
echo           VALIXIS STUDIO -- 24/7 AUTONOMOUS LEAD & OUTREACH ENGINE
echo =====================================================================
echo  [+] Dedicated Server Mode: Active
echo  [+] Lead Sourcing: E-Commerce, Clinics, Cafes, Startups, Real Estate
echo  [+] AI Engine: Gemini 3.5 Flash-Lite
echo  [+] WhatsApp Server Bridge: http://localhost:3001/send-task-alert
echo  [+] Jarvis Voice Caller: Operational
echo =====================================================================
echo.

cd /d "%~dp0"

echo Launching 24/7 Outbound Daemon...
python lead_engine_daemon.py

pause
