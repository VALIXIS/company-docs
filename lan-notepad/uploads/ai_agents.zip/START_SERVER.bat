@echo off
title Valixis AI Server
color 0A
cls
echo ============================================
echo   VALIXIS AI — Starting Web Server...
echo ============================================
echo.
cd /d "%~dp0"
python server.py
echo.
echo Server stopped. Press any key to restart...
pause >nul
goto :0
