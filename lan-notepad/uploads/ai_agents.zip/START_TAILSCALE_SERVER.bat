@echo off
title Valixis AI 24/7 Tailscale Server
color 0B
cls
cd /d "%~dp0"

echo ==============================================================
echo        VALIXIS AI 24/7 SUITE - TAILSCALE HOST
echo ==============================================================
echo.

:: Detect Tailscale IP if tailscale is installed and running
for /f "tokens=*" %%i in ('tailscale ip -4 2^>nul') do set TAILSCALE_IP=%%i

if defined TAILSCALE_IP (
    echo [✓] Tailscale IP Detected: %TAILSCALE_IP%
    echo.
    echo 🌐 ACCESS YOUR AI SUITE FROM ANY DEVICE IN YOUR TAILNET:
    echo    http://%TAILSCALE_IP%:8000
    echo ==============================================================
) else (
    echo [!] Tailscale CLI not detected or offline.
    echo     Accessible on local network via port 8000.
    echo ==============================================================
)
echo.

:LOOP
echo Starting Valixis AI Server on 0.0.0.0:8000...
python server.py
echo.
echo [!] Server stopped unexpectedly at %TIME%.
echo Restarting in 5 seconds (Press Ctrl+C to stop)...
timeout /t 5 >nul
goto LOOP
