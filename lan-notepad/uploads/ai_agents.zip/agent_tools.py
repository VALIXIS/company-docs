"""
🛠️ Agent Tools Execution Module
Gives agents direct read access to:
- Official Gmail inbox (official.valixis@gmail.com)
- Live GitHub repositories & file trees via GitHub REST API (works anywhere, across laptops!)
- Local Documents projects
- 1-click mobile Google Calendar add links
"""

import email
from email.header import decode_header
import imaplib
import json
import os
import urllib.parse
import urllib.request
import urllib.error
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

GMAIL_USER = os.getenv("GMAIL_USER", "official.valixis@gmail.com")
GMAIL_APP_PASSWORD = os.getenv("GMAIL_APP_PASSWORD", "rkvzxaxiirbgfmvv")
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "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")
DOCS_DIR = os.path.expanduser("~/Documents")

def decode_mime_words(raw_header):
    if not raw_header:
        return ""
    decoded = decode_header(raw_header)
    parts = []
    for text, encoding in decoded:
        if isinstance(text, bytes):
            parts.append(text.decode(encoding or "utf-8", errors="ignore"))
        else:
            parts.append(str(text))
    return "".join(parts)

# ── Email Fetcher ─────────────────────────────────────────────────────────────

def get_recent_emails(count: int = 5) -> str:
    """Fetches recent emails from official.valixis@gmail.com."""
    try:
        mail = imaplib.IMAP4_SSL("imap.gmail.com")
        mail.login(GMAIL_USER, GMAIL_APP_PASSWORD)
        mail.select("INBOX")
        status, response = mail.search(None, "ALL")
        if status != "OK" or not response[0]:
            mail.logout()
            return "Inbox is empty."
        
        msg_ids = response[0].split()
        latest_ids = msg_ids[-count:]
        latest_ids.reverse()

        results = []
        for mid in latest_ids:
            status, data = mail.fetch(mid, "(RFC822)")
            if status != "OK" or not data:
                continue
            raw = data[0][1]
            msg = email.message_from_bytes(raw)
            from_hdr = decode_mime_words(msg.get("From", ""))
            subject = decode_mime_words(msg.get("Subject", "(No Subject)"))
            date_hdr = msg.get("Date", "")
            
            body = ""
            if msg.is_multipart():
                for part in msg.walk():
                    if part.get_content_type() == "text/plain":
                        payload = part.get_payload(decode=True)
                        if payload:
                            body = payload.decode(errors="ignore")[:300]
                            break
            else:
                payload = msg.get_payload(decode=True)
                if payload:
                    body = payload.decode(errors="ignore")[:300]

            results.append(f"📧 From: {from_hdr}\nSubject: {subject}\nDate: {date_hdr}\nPreview: {body.strip()}\n---")

        mail.logout()
        return "\n\n".join(results)
    except Exception as e:
        return f"Email Fetch Error: {str(e)}"

# ── GitHub Repositories (Cloud-Native, works on any laptop!) ──────────────────

def list_github_repos(count: int = 15) -> str:
    """Fetches user's repositories from GitHub API."""
    if not GITHUB_TOKEN:
        return "GITHUB_TOKEN is not configured."
    url = f"https://api.github.com/user/repos?per_page={count}&sort=updated"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"token {GITHUB_TOKEN}",
            "User-Agent": "Valixis-AI-Agent",
            "Accept": "application/vnd.github.v3+json",
        }
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as res:
            repos = json.loads(res.read().decode("utf-8"))
            lines = [f"🐙 GitHub Repositories for Subhash ({len(repos)} active):"]
            for r in repos:
                desc = f" - {r['description']}" if r.get("description") else ""
                lines.append(f"• {r['name']} ({r.get('visibility', 'public')}){desc} [Branch: {r.get('default_branch', 'main')}]")
            return "\n".join(lines)
    except Exception as e:
        return f"GitHub API Error: {str(e)}"

def get_repo_file_content(repo_name: str, file_path: str) -> str:
    """Reads a file directly from a GitHub repository via API."""
    if not GITHUB_TOKEN:
        return "GITHUB_TOKEN not configured."
    # Get user login
    user_url = "https://api.github.com/user"
    user_req = urllib.request.Request(user_url, headers={"Authorization": f"token {GITHUB_TOKEN}", "User-Agent": "Valixis"})
    with urllib.request.urlopen(user_req, timeout=5) as u_res:
        user_login = json.loads(u_res.read().decode())["login"]

    url = f"https://api.github.com/repos/{user_login}/{repo_name}/contents/{file_path}"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"token {GITHUB_TOKEN}",
            "User-Agent": "Valixis-AI-Agent",
            "Accept": "application/vnd.github.v3.raw",
        }
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as res:
            return res.read().decode("utf-8", errors="ignore")[:3500]
    except Exception as e:
        return f"Could not read {file_path} from {repo_name}: {str(e)}"

# ── Local Projects ────────────────────────────────────────────────────────────

def list_projects() -> str:
    """Lists your active local projects in Documents."""
    try:
        projects_dir = os.path.join(DOCS_DIR, "PROJECTS")
        valixis_dir = os.path.join(DOCS_DIR, "VALIXIS", "Projects")
        
        found = []
        if os.path.exists(projects_dir):
            for d in os.listdir(projects_dir):
                if os.path.isdir(os.path.join(projects_dir, d)):
                    found.append(f"📁 PROJECTS/{d}")
        if os.path.exists(valixis_dir):
            for d in os.listdir(valixis_dir):
                if os.path.isdir(os.path.join(valixis_dir, d)):
                    found.append(f"📁 VALIXIS/Projects/{d}")
        
        return "Your active project directories:\n" + "\n".join(found[:25])
    except Exception as e:
        return f"Projects List Error: {str(e)}"

# ── Calendar 1-Click Link Generator ───────────────────────────────────────────

def create_calendar_link(title: str, start_dt: str, end_dt: str, details: str = "") -> str:
    """Generates a 1-click Google Calendar add link that opens directly on mobile."""
    start_fmt = start_dt.replace("-", "").replace(":", "").replace(" ", "T")
    end_fmt = end_dt.replace("-", "").replace(":", "").replace(" ", "T")
    params = {
        "action": "TEMPLATE",
        "text": title,
        "dates": f"{start_fmt}/{end_fmt}",
        "details": details,
    }
    link = "https://calendar.google.com/calendar/render?" + urllib.parse.urlencode(params)
    return link

# ── Live Outbound Pipeline & Lead Intelligence ────────────────────────────────

def get_outbound_pipeline_summary() -> str:
    """Queries data/leads.db to return live outbound stats and recent prospects."""
    db_path = os.path.join(os.path.dirname(__file__), "data", "leads.db")
    if not os.path.exists(db_path):
        return "No outbound leads database found yet. Run lead hunter first."
    
    try:
        import sqlite3
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute("SELECT status, count(*) as cnt FROM leads GROUP BY status")
        counts = {row["status"]: row["cnt"] for row in cursor.fetchall()}

        cursor.execute("""
        SELECT company, niche, location, score, status, email, phone, linkedin_url
        FROM leads
        ORDER BY id DESC LIMIT 5
        """)
        recent_leads = cursor.fetchall()
        conn.close()

        summary_lines = [
            "[VALIXIS 24/7 OUTBOUND PIPELINE LIVE STATUS]",
            f"- Total Leads Hunted: {sum(counts.values())}",
            f"- Qualified & Pitch-Crafted: {counts.get('QUALIFIED', 0) + counts.get('CONTACTED_EMAIL', 0) + counts.get('CONTACTED_WA', 0) + counts.get('STAGED_LINKEDIN', 0)}",
            f"- Cold Emails Dispatched: {counts.get('CONTACTED_EMAIL', 0)}",
            f"- Cold WhatsApp Sent: {counts.get('CONTACTED_WA', 0)}",
            f"- LinkedIn Prospects Staged: {counts.get('STAGED_LINKEDIN', 0)}",
            f"- Inbound Client Replies: {counts.get('REPLIED', 0)}",
            "",
            "Recent Prospects in Pipeline:"
        ]

        for lead in recent_leads:
            summary_lines.append(
                f"- {lead['company']} ({lead['niche']}, {lead['location']}) | Score: {lead['score']}/100 | Status: {lead['status']}"
            )

        return "\n".join(summary_lines)
    except Exception as e:
        return f"Outbound Pipeline Query Error: {str(e)}"

