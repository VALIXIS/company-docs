import smtplib
import uuid
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta, timezone
from dotenv import load_dotenv

load_dotenv()

DEFAULT_RECIPIENT = os.getenv("PERSONAL_EMAIL", "nagasubhash55@gmail.com")
DEFAULT_SENDER = os.getenv("GMAIL_USER", "official.valixis@gmail.com")
DEFAULT_PASSWORD = os.getenv("GMAIL_APP_PASSWORD", "rkvzxaxiirbgfmvv")

# IST timezone (+05:30)
IST = timezone(timedelta(hours=5, minutes=30))

def send_calendar_invite(
    summary: str,
    start_dt_ist: datetime,
    duration_minutes: int = 60,
    description: str = "",
    recipient: str = DEFAULT_RECIPIENT,
    sender: str = DEFAULT_SENDER,
    password: str = DEFAULT_PASSWORD
) -> bool:
    """
    Sends an iCalendar (.ics) invite with explicit VTIMEZONE for Asia/Kolkata (IST).
    start_dt_ist can be naive (assumed IST) or timezone-aware.
    """
    # Ensure start_dt has IST timezone
    if start_dt_ist.tzinfo is None:
        start_dt_ist = start_dt_ist.replace(tzinfo=IST)
    else:
        start_dt_ist = start_dt_ist.astimezone(IST)

    end_dt_ist = start_dt_ist + timedelta(minutes=duration_minutes)

    # Local formatted strings for Asia/Kolkata
    dtstart_local = start_dt_ist.strftime("%Y%m%dT%H%M%S")
    dtend_local = end_dt_ist.strftime("%Y%m%dT%H%M%S")
    
    # UTC timestamp for creation
    dtstamp_utc = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    uid = f"{uuid.uuid4()}@valixis.ai"

    ics_content = f"""BEGIN:VCALENDAR
PRODID:-//Valixis AI Chief of Staff//EN
VERSION:2.0
CALSCALE:GREGORIAN
METHOD:REQUEST
BEGIN:VTIMEZONE
TZID:Asia/Kolkata
X-LIC-LOCATION:Asia/Kolkata
BEGIN:STANDARD
TZOFFSETFROM:+0530
TZOFFSETTO:+0530
TZNAME:IST
DTSTART:19700101T000000
END:STANDARD
END:VTIMEZONE
BEGIN:VEVENT
UID:{uid}
DTSTAMP:{dtstamp_utc}
DTSTART;TZID=Asia/Kolkata:{dtstart_local}
DTEND;TZID=Asia/Kolkata:{dtend_local}
SUMMARY:{summary}
DESCRIPTION:{description}
ORGANIZER;CN=Valixis AI:mailto:{sender}
ATTENDEE;ROLE=REQ-PARTICIPANT;PARTSTAT=ACCEPTED;CN=Subhash:mailto:{recipient}
STATUS:CONFIRMED
TRANSP:OPAQUE
SEQUENCE:0
END:VEVENT
END:VCALENDAR
"""

    msg = MIMEMultipart("mixed")
    msg["From"] = f"Valixis AI <{sender}>"
    msg["To"] = recipient
    msg["Subject"] = f"📅 Calendar Invite: {summary}"

    time_str = start_dt_ist.strftime("%A, %b %d at %I:%M %p IST")
    body_part = MIMEText(
        f"Subhash, your AI Chief of Staff scheduled '{summary}' for {time_str}.\n\nThis event is automatically saved to your Google Calendar.",
        "plain",
        "utf-8"
    )
    msg.attach(body_part)

    ics_part = MIMEBase("text", "calendar", method="REQUEST", name="event.ics")
    ics_part.set_payload(ics_content.encode("utf-8"))
    encoders.encode_base64(ics_part)
    ics_part.add_header("Content-class", "urn:content-classes:calendarmessage")
    ics_part.add_header("Filename", "event.ics")
    ics_part.add_header("Path", "event.ics")
    msg.attach(ics_part)

    with smtplib.SMTP("smtp.gmail.com", 587) as server:
        server.starttls()
        server.login(sender, password)
        server.send_message(msg)

    return True

if __name__ == "__main__":
    # Test 3:30 PM tomorrow IST
    tomorrow_330pm = datetime.now(IST) + timedelta(days=1)
    tomorrow_330pm = tomorrow_330pm.replace(hour=15, minute=30, second=0, microsecond=0)
    success = send_calendar_invite(
        summary="Deep Work Block: Valixis Architecture",
        start_dt_ist=tomorrow_330pm,
        duration_minutes=60,
        description="Automated Deep Work scheduling in IST timezone"
    )
    print("Sent test invite for 3:30 PM IST:", success)
