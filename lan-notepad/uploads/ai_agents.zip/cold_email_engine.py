"""
âœ‰ï¸  Cold Email Outreach Engine
Executes paced, authenticated cold email dispatch via official.valixis@gmail.com
"""

import os
import time
import smtplib
import sqlite3
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger("ColdEmailEngine")
logger.setLevel(logging.INFO)

DB_PATH = os.path.join(os.path.dirname(__file__), "data", "leads.db")
GMAIL_USER = os.getenv("GMAIL_USER", "official.valixis@gmail.com")
GMAIL_APP_PASSWORD = os.getenv("GMAIL_APP_PASSWORD", "rkvzxaxiirbgfmvv")
SENDER_NAME = os.getenv("SENDER_NAME", "Subhash (VALIXIS Studio)")

SIGNATURE = """
--
Best regards,

Subhash
Founder & Lead Architect | VALIXIS Studio
Web: https://valixis.com
WhatsApp / Direct: +91 9603416707
official.valixis@gmail.com
"""

def send_single_cold_email(to_email: str, subject: str, body_text: str) -> bool:
    """Dispatches a personalized email via Gmail SSL SMTP."""
    full_body = body_text.strip() + "\n\n" + SIGNATURE

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = f"{SENDER_NAME} <{GMAIL_USER}>"
    msg["To"] = to_email
    msg["Reply-To"] = GMAIL_USER

    # Plain text version
    part = MIMEText(full_body, "plain", "utf-8")
    msg.attach(part)

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(GMAIL_USER, GMAIL_APP_PASSWORD)
            server.sendmail(GMAIL_USER, [to_email], msg.as_string())
        logger.info(f"âœ… Cold email dispatched to {to_email}")
        return True
    except Exception as e:
        logger.error(f"â Œ Failed to send email to {to_email}: {e}")
        return False

def dispatch_email_batch(batch_size: int = 3, delay_seconds: int = 10) -> int:
    """Fetches QUALIFIED leads with emails and sends outreach."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("""
    SELECT id, company, email, cold_email_copy
    FROM leads
    WHERE status = 'QUALIFIED' AND email IS NOT NULL AND email != ''
    LIMIT ?
    """, (batch_size,))
    
    leads = cursor.fetchall()
    if not leads:
        conn.close()
        logger.info("No qualified leads ready for email outreach.")
        return 0

    sent_count = 0
    for lead in leads:
        lead_id = lead["id"]
        to_email = lead["email"]
        copy = lead["cold_email_copy"] or ""
        
        # Parse Subject and Body
        subject = f"Growth opportunity for {lead['company']}"
        body = copy
        if copy.startswith("Subject:"):
            parts = copy.split("\n\n", 1)
            subject = parts[0].replace("Subject:", "").strip()
            body = parts[1] if len(parts) > 1 else copy

        logger.info(f"Dispatching email to {lead['company']} ({to_email})...")
        
        # Don't send real spam to test fake domains ending in .example.com
        if to_email.endswith(".example.com"):
            logger.info(f"[SIMULATED DISPATCH] Successfully verified email pipeline for {to_email}")
            success = True
        else:
            success = send_single_cold_email(to_email, subject, body)

        if success:
            cursor.execute("""
            UPDATE leads
            SET status = 'CONTACTED_EMAIL', updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """, (lead_id,))
            conn.commit()
            sent_count += 1
            time.sleep(delay_seconds)

    conn.close()
    return sent_count

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print("Testing Cold Email Engine...")
    count = dispatch_email_batch(batch_size=2, delay_seconds=2)
    print(f"Sent {count} emails.")
