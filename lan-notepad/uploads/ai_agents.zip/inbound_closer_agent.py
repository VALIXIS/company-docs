"""
ðŸ¤– 24/7 Inbound Closer Agent
Monitors official.valixis@gmail.com for client responses and inquiries.
- Analyzes buyer intent via Gemini 3.5 Flash-Lite
- Normal inquiry: Drafts response and alerts Subhash on WhatsApp
- Urgent / Deal-Closing intent: Triggers Jarvis Voice Call to Subhash immediately!
"""

import os
import time
import email
from email.header import decode_header
import imaplib
import json
import logging
from datetime import datetime
from dotenv import load_dotenv
from google import genai
from google.genai import types

load_dotenv()

logger = logging.getLogger("InboundCloser")
logger.setLevel(logging.INFO)

from whatsapp_client import notify_subhash
from jarvis_caller import trigger_jarvis_urgent_call

GMAIL_USER = os.getenv("GMAIL_USER", "official.valixis@gmail.com")
GMAIL_APP_PASSWORD = os.getenv("GMAIL_APP_PASSWORD", "rkvzxaxiirbgfmvv")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

CHECK_INTERVAL_SECONDS = 30  # Scan inbox every 30 seconds

def decode_mime_words(raw_header):
    if not raw_header:
        return ""
    decoded = decode_header(raw_header)
    parts = []
    for text, encoding in decoded:
        if isinstance(text, bytes):
            parts.append(text.decode(encoding or "utf-8", errors="ignore"))
        else:
            parts.append(str(text))
    return "".join(parts)

def classify_inbound_intent(sender: str, subject: str, body: str) -> dict:
    """Uses Gemini 3.5 Flash-Lite to evaluate buyer intent and craft a founder response."""
    client = genai.Client(api_key=GEMINI_API_KEY)
    
    prompt = f"""
You are the AI Chief of Staff and Sales Lead for Subhash, Founder of VALIXIS Studio.
Analyze this incoming email from a client or prospect:
- From: {sender}
- Subject: {subject}
- Content:
{body[:2000]}

Classify the intent into one of:
1. "DEAL_CLOSING": The prospect wants to get on a call, book a meeting, asks for a proposal/invoice, asks for pricing, or is ready to start immediately.
2. "GENERAL_INQUIRY": Asking for portfolio, case studies, or generic questions.
3. "NOT_INTERESTED": Rejection, unsubscribe, or spam.

Return ONLY a JSON object:
{{
  "intent": "DEAL_CLOSING" | "GENERAL_INQUIRY" | "NOT_INTERESTED",
  "client_name": "<estimated name or Company>",
  "deal_value_estimate": "<e.g. $2,500 - $5,000 or High-Ticket>",
  "summary": "<1-2 sentence executive summary of what the client wants>",
  "draft_reply": "<punchy, authoritative 3-sentence reply in Subhash's founder voice to lock in the next step>"
}}
"""
    try:
        response = client.models.generate_content(
            model="gemini-3.5-flash-lite",
            contents=prompt,
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                temperature=0.2
            )
        )
        return json.loads(response.text.strip())
    except Exception as e:
        logger.error(f"Error classifying intent with Gemini: {e}")
        return {
            "intent": "DEAL_CLOSING" if any(k in body.lower() for k in ["call", "pricing", "quote", "meeting", "cost"]) else "GENERAL_INQUIRY",
            "client_name": sender.split("<")[0].strip() or "Client",
            "deal_value_estimate": "High-Ticket",
            "summary": f"Inquiry regarding {subject}",
            "draft_reply": "Hi, thanks for reaching out. Let's set up a quick 10-minute sync this week to finalize the details and align on the roadmap. What time works best for you?"
        }

def check_for_inbound_leads():
    """Polls Gmail inbox via IMAP for unread incoming client messages."""
    try:
        mail = imaplib.IMAP4_SSL("imap.gmail.com")
        mail.login(GMAIL_USER, GMAIL_APP_PASSWORD)
        mail.select("INBOX")
        
        # Search for unread emails
        status, response = mail.search(None, "UNSEEN")
        if status != "OK" or not response[0]:
            mail.logout()
            return

        msg_ids = response[0].split()
        logger.info(f"Found {len(msg_ids)} unread email(s) in inbox.")

        for mid in msg_ids:
            status, data = mail.fetch(mid, "(RFC822)")
            if status != "OK" or not data:
                continue
                
            raw = data[0][1]
            msg = email.message_from_bytes(raw)
            sender = decode_mime_words(msg.get("From", ""))
            subject = decode_mime_words(msg.get("Subject", "(No Subject)"))
            
            # Extract plain text body
            body = ""
            if msg.is_multipart():
                for part in msg.walk():
                    if part.get_content_type() == "text/plain":
                        payload = part.get_payload(decode=True)
                        if payload:
                            body = payload.decode(errors="ignore")
                            break
            else:
                payload = msg.get_payload(decode=True)
                if payload:
                    body = payload.decode(errors="ignore")

            logger.info(f"Processing inbound email from {sender}: {subject}")
            analysis = classify_inbound_intent(sender, subject, body)
            intent = analysis.get("intent", "GENERAL_INQUIRY")
            client_name = analysis.get("client_name", "Client")
            summary = analysis.get("summary", "")
            draft = analysis.get("draft_reply", "")
            deal_value = analysis.get("deal_value_estimate", "$3,000+")

            if intent == "DEAL_CLOSING":
                logger.info(f"ðŸš¨ DEAL CLOSING DETECTED! Triggering Jarvis Call to Subhash...")
                trigger_jarvis_urgent_call(
                    lead_name=client_name,
                    company=sender,
                    intent_summary=summary,
                    deal_value=deal_value
                )
            elif intent == "GENERAL_INQUIRY":
                logger.info(f"Client inquiry received. Sending WhatsApp alert to Subhash...")
                wa_msg = (
                    f"ðŸ“¨ *NEW CLIENT INQUIRY*\n\n"
                    f"ðŸ‘¤ *From:* {sender}\n"
                    f"ðŸ“Œ *Subject:* {subject}\n"
                    f"ðŸ“  *Summary:* {summary}\n\n"
                    f"âœ ï¸  *Drafted Founder Reply:*\n\"{draft}\"\n\n"
                    f"ðŸ‘‰ _Reply to send this email or hop on your inbox._"
                )
                notify_subhash(wa_msg, title="ðŸ’¬ CLIENT INBOUND")

            # Mark email as read so we don't alert repeatedly
            mail.store(mid, "+FLAGS", "\\Seen")

        mail.logout()
    except Exception as e:
        logger.error(f"Error checking inbound emails: {e}")

def main():
    logger.info("Starting 24/7 Inbound Closer Poller...")
    while True:
        try:
            check_for_inbound_leads()
            time.sleep(CHECK_INTERVAL_SECONDS)
        except KeyboardInterrupt:
            logger.info("Inbound closer stopped.")
            break
        except Exception as e:
            logger.error(f"Inbound closer loop error: {e}")
            time.sleep(10)

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    main()
