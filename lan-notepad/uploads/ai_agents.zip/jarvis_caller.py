"""
ðŸŽ™ï¸  Jarvis Urgent Voice Caller & Emergency Dispatcher
Handles urgent phone alerts for Subhash when high-ticket leads reply or critical events occur.
Operates 100% FREE without requiring paid services, with optional Twilio Voice support.
"""

import os
import sys
import time
import logging
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger("JarvisCaller")
logger.setLevel(logging.INFO)

from whatsapp_client import notify_subhash

# Optional Twilio Credentials (can use Twilio Free Trial)
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
TWILIO_PHONE_NUMBER = os.getenv("TWILIO_PHONE_NUMBER")
SUBHASH_PHONE = os.getenv("ALERT_PHONE", "+919603416707")

def synthesize_jarvis_speech(text: str, output_path: str = "data/jarvis_alert.wav") -> str:
    """
    Synthesizes speech using local pyttsx3 offline engine (100% Free).
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    try:
        import pyttsx3
        engine = pyttsx3.init()
        # Adjust rate and volume for executive crispness
        engine.setProperty("rate", 175)
        engine.setProperty("volume", 1.0)
        
        # Pick best voice if available
        voices = engine.getProperty("voices")
        for voice in voices:
            if "david" in voice.name.lower() or "george" in voice.name.lower() or "brian" in voice.name.lower():
                engine.setProperty("voice", voice.id)
                break
                
        engine.save_to_file(text, output_path)
        engine.runAndWait()
        logger.info(f"âœ… Jarvis speech synthesized at: {output_path}")
        return output_path
    except Exception as e:
        logger.warning(f"Speech synthesis fallback: {e}")
        return ""

def make_twilio_phone_call(to_number: str, speech_text: str) -> bool:
    """
    Calls phone directly via Twilio Voice API if credentials are configured.
    """
    if not (TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN and TWILIO_PHONE_NUMBER):
        return False
    
    try:
        from twilio.rest import Client
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        twiml = f'<Response><Say voice="Polly.Brian" language="en-GB">{speech_text}</Say></Response>'
        call = client.calls.create(
            twiml=twiml,
            to=to_number,
            from_=TWILIO_PHONE_NUMBER
        )
        logger.info(f"âœ… Twilio call initiated: SID {call.sid}")
        return True
    except Exception as e:
        logger.error(f"â Œ Twilio call failed: {e}")
        return False

def trigger_jarvis_urgent_call(lead_name: str, company: str, intent_summary: str, deal_value: str = "High-Ticket") -> bool:
    """
    Primary trigger when an urgent event or hot lead requires Subhash's immediate attention.
    1. Generates voice speech script.
    2. Tries Twilio phone ring if configured.
    3. Sends high-priority emergency WhatsApp dispatch to Subhash.
    """
    current_time = datetime.now().strftime("%I:%M %p")
    
    voice_script = (
        f"Good day Subhash. This is Jarvis calling from your VALIXIS server. "
        f"Urgent priority alert: {lead_name} from {company} has expressed immediate interest in our agency services. "
        f"They stated: {intent_summary}. "
        f"I have staged the response and sent the details to your WhatsApp. Please review."
    )
    
    # 1. Synthesize local audio
    audio_file = synthesize_jarvis_speech(voice_script)
    
    # 2. Try actual phone call if Twilio is set
    call_made = False
    if TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN:
        logger.info("Dialing Subhash's phone via Twilio...")
        call_made = make_twilio_phone_call(SUBHASH_PHONE, voice_script)
    
    # 3. Send urgent WhatsApp Emergency Ping
    wa_alert = (
        f"ðŸ“ž *[INCOMING CALL FROM JARVIS]*\n\n"
        f"ðŸ”” *PRIORITY ALERT:* Hot Lead Ready To Close\n"
        f"â° *Time:* {current_time} IST\n"
        f"ðŸ‘¤ *Contact:* {lead_name} ({company})\n"
        f"ðŸ’° *Estimated Opportunity:* {deal_value}\n\n"
        f"ðŸ’¬ *Client Intent:* \"{intent_summary}\"\n\n"
        f"ðŸŽ™ï¸  *Jarvis Voice Briefing:* \"{voice_script}\"\n\n"
        f"ðŸ‘‰ _Check your email or reply here to approve the drafted response._"
    )
    
    notify_subhash(wa_alert, title="ðŸš🚨 JARVIS EMERGENCY CALL")
    return True

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print("Testing Jarvis Urgent Alert System...")
    trigger_jarvis_urgent_call(
        lead_name="Alexander Wright",
        company="Solstice Aesthetics Dental",
        intent_summary="Need an AI appointment assistant and redesigned landing page immediately. What is your pricing?",
        deal_value="$4,500+"
    )
