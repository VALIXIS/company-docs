"""
âš™ï¸  Autonomous Lead Engine & Jarvis Daemon
Runs continuously 24/7 on Subhash's server laptop:
- Discovers high-intent leads across target niches (E-com, Clinics, Cafes, Startups, Real Estate)
- Qualifies & crafts personalized pitches via Gemini
- Executes paced email & WhatsApp cold outreach autonomously
- Formats & alerts LinkedIn queues to Subhash (for 1-click execution)
- Triggers Jarvis emergency voice calls upon hot inbound replies
"""

import os
import sys
import time
import logging
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger("LeadEngineDaemon")

from lead_hunter import hunt_leads_batch, init_db
from lead_qualifier import qualify_unprocessed_leads
from cold_email_engine import dispatch_email_batch
from whatsapp_outreach_engine import dispatch_whatsapp_batch
from linkedin_queue import generate_linkedin_batch
from whatsapp_client import send_whatsapp_message, notify_subhash
from jarvis_caller import trigger_jarvis_urgent_call
from inbound_closer_agent import check_for_inbound_leads

# Configuration
CYCLE_INTERVAL_SECONDS = 300  # 5 minutes between execution passes

def run_lead_engine_cycle():
    """Executes one full pass of the autonomous outbound engine."""
    logger.info("â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• ")
    logger.info("ðŸš€ Starting Outbound Engine Execution Pass")
    logger.info("â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• â• ")

    # 1. Lead Sourcing
    try:
        new_leads = hunt_leads_batch(max_leads=5)
        logger.info(f"Phase 1 [Hunt]: Discovered {new_leads} new prospects.")
    except Exception as e:
        logger.error(f"Phase 1 [Hunt] error: {e}")

    # 2. AI Qualification & Copy Generation
    try:
        qualified = qualify_unprocessed_leads(limit=5)
        logger.info(f"Phase 2 [Qualify]: Scored & drafted copy for {qualified} leads.")
    except Exception as e:
        logger.error(f"Phase 2 [Qualify] error: {e}")

    # 3. Cold Email Outreach (100% Autonomous via Gmail SMTP)
    try:
        sent_emails = dispatch_email_batch(batch_size=3, delay_seconds=5)
        logger.info(f"Phase 3 [Email]: Dispatched {sent_emails} cold outreach emails.")
    except Exception as e:
        logger.error(f"Phase 3 [Email] error: {e}")

    # 4. Cold WhatsApp Outreach (100% Autonomous via Old Laptop Server :3001)
    try:
        sent_wa = dispatch_whatsapp_batch(batch_size=2, cooldown_seconds=15)
        logger.info(f"Phase 4 [WhatsApp]: Dispatched {sent_wa} cold WhatsApp messages to prospects.")
    except Exception as e:
        logger.error(f"Phase 4 [WhatsApp] error: {e}")

    # 5. LinkedIn Staging Queue (Pre-written cards sent to Subhash on WhatsApp)
    try:
        staged_path = generate_linkedin_batch(batch_size=3)
        if staged_path:
            logger.info(f"Phase 5 [LinkedIn]: Staged batch at {staged_path}")
    except Exception as e:
        logger.error(f"Phase 5 [LinkedIn] error: {e}")

    # 6. Inbound Client Replies & Deal Closing Monitor
    try:
        logger.info("Phase 6 [Inbound Closer]: Scanning for client replies...")
        check_for_inbound_leads()
    except Exception as e:
        logger.error(f"Phase 6 [Inbound Closer] error: {e}")

def main():
    logger.info("Initializing VALIXIS Outbound Lead Engine & Jarvis Daemon...")
    init_db()
    
    # Notify Subhash on WhatsApp that the 24/7 daemon has spun up
    notify_subhash(
        "ðŸš€ *VALIXIS 24/7 Full Autonomous Agency OS is LIVE!*\n\n"
        "âœ… Lead Hunter: Active (E-Com, Clinics, Cafes, Startups, Real Estate)\n"
        "âœ… Cold Emails: Auto-dispatching via official.valixis@gmail.com\n"
        "âœ… Cold WhatsApp: Auto-dispatching via port 3001\n"
        "âœ… LinkedIn Queue: Auto-staging daily files + WhatsApp 1-click cards\n"
        "âœ… Inbound Closer: Monitoring replies & ready to trigger Jarvis Call",
        title="VALIXIS SYSTEM ONLINE"
    )

    while True:
        try:
            run_lead_engine_cycle()
            logger.info(f"Cycle complete. Waiting {CYCLE_INTERVAL_SECONDS}s for next cycle...\n")
            time.sleep(CYCLE_INTERVAL_SECONDS)
        except KeyboardInterrupt:
            logger.info("Daemon gracefully stopped by user.")
            break
        except Exception as e:
            logger.error(f"Unexpected error in daemon loop: {e}")
            time.sleep(30)

if __name__ == "__main__":
    main()
