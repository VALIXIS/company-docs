"""
ðŸ§  Lead Qualifier & AI Pitch Crafter
Uses Gemini 3.5 Flash-Lite to score leads (0-100) and generate hyper-personalized
outreach copy across Email, WhatsApp, and LinkedIn.
"""

import os
import json
import sqlite3
import logging
from typing import Dict, Any, List
from dotenv import load_dotenv
from google import genai
from google.genai import types

load_dotenv()

logger = logging.getLogger("LeadQualifier")
logger.setLevel(logging.INFO)

DB_PATH = os.path.join(os.path.dirname(__file__), "data", "leads.db")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

QUALIFICATION_PROMPT = """
You are the Chief Growth Strategist for VALIXIS Studio, an elite agency founded by Subhash specializing in:
1. High-converting Web & Mobile Applications (Next.js, Flutter, Fast UI/UX)
2. Custom AI Agents & Business OS Automation (Automated CRM, Inbound Lead Closer, Support Bots)
3. WhatsApp & Workflow Automation (Automatic patient/customer booking, ordering)

Analyze this prospective lead and generate bespoke outreach angles:
- Company: {company}
- Niche: {niche}
- Location: {location}, {country}
- Website: {website}

Return ONLY valid JSON matching this exact structure:
{{
  "score": <integer from 0 to 100 representing fit and buying power>,
  "pitch_angle": "<one-sentence strategic value proposition tailored to their specific niche>",
  "cold_email_subject": "<irresistible, curiosity-driven 3-6 word subject line>",
  "cold_email_body": "<concise, professional 3-sentence email from Subhash highlighting their exact niche benefit with a low-friction call to action>",
  "whatsapp_message": "<casual, punchy 2-sentence WhatsApp icebreaker addressed to the founder/owner>",
  "linkedin_note": "<personalized connection note under 280 characters highlighting mutual interest in their sector>"
}}
"""

def get_gemini_client():
    return genai.Client(api_key=GEMINI_API_KEY)

def qualify_single_lead(client, lead: dict) -> Dict[str, Any]:
    """Qualifies a lead using Gemini 3.5 Flash-Lite."""
    prompt = QUALIFICATION_PROMPT.format(
        company=lead.get("company", "Company"),
        niche=lead.get("niche", "General Business"),
        location=lead.get("location", "Global"),
        country=lead.get("country", ""),
        website=lead.get("website", "")
    )

    try:
        response = client.models.generate_content(
            model="gemini-3.5-flash-lite",
            contents=prompt,
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                temperature=0.3
            )
        )
        return json.loads(response.text.strip())
    except Exception as e:
        logger.error(f"Error qualifying {lead.get('company')}: {e}")
        # Robust default fallback
        return {
            "score": 75,
            "pitch_angle": f"Bespoke AI automation & modern web systems for {lead.get('company')}",
            "cold_email_subject": f"Quick idea for {lead.get('company')}",
            "cold_email_body": f"Hi team, I noticed {lead.get('company')} is growing in {lead.get('location')}. At VALIXIS Studio, we help companies in your space automate inbound lead handling and build high-performance web platforms. Open to a 5-minute preview of what we could streamline for you?",
            "whatsapp_message": f"Hey, came across {lead.get('company')}'s work in {lead.get('location')}. Loved what you're building—we help teams streamline operations with custom AI bots. Worth a quick chat?",
            "linkedin_note": f"Hi, noticed your work with {lead.get('company')} in {lead.get('location')}. Would love to connect and follow your journey!"
        }

def qualify_unprocessed_leads(limit: int = 5) -> int:
    """Fetches leads with status='NEW', scores them, and updates the database."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM leads WHERE status = 'NEW' LIMIT ?", (limit,))
    rows = cursor.fetchall()
    
    if not rows:
        conn.close()
        logger.info("No unanalyzed leads found.")
        return 0

    client = get_gemini_client()
    qualified_count = 0

    for row in rows:
        lead_dict = dict(row)
        logger.info(f"Qualifying lead: {lead_dict['company']} ({lead_dict['niche']})...")
        
        result = qualify_single_lead(client, lead_dict)
        
        full_email = f"Subject: {result['cold_email_subject']}\n\n{result['cold_email_body']}"
        
        cursor.execute("""
        UPDATE leads
        SET score = ?,
            pitch_angle = ?,
            cold_email_copy = ?,
            whatsapp_copy = ?,
            linkedin_copy = ?,
            status = 'QUALIFIED',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """, (
            result.get("score", 70),
            result.get("pitch_angle", ""),
            full_email,
            result.get("whatsapp_message", ""),
            result.get("linkedin_note", ""),
            lead_dict["id"]
        ))
        conn.commit()
        qualified_count += 1
        logger.info(f"âœ… Lead {lead_dict['company']} scored {result.get('score')}/100")

    conn.close()
    return qualified_count

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print("Testing Lead Qualification engine...")
    count = qualify_unprocessed_leads(limit=3)
    print(f"Qualified {count} leads.")
