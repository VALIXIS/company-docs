"""
ðŸ’¼ LinkedIn Staging Queue & WhatsApp Notification Dispatcher
Batches high-ticket LinkedIn prospects into clean action files and sends
1-click copy-paste cards directly to Subhash's personal WhatsApp.
"""

import os
import sqlite3
import logging
from datetime import datetime
from whatsapp_client import notify_subhash

logger = logging.getLogger("LinkedInQueue")
logger.setLevel(logging.INFO)

DB_PATH = os.path.join(os.path.dirname(__file__), "data", "leads.db")
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "data", "linkedin_queue")

def generate_linkedin_batch(batch_size: int = 5) -> str:
    """
    Pulls qualified leads with LinkedIn URLs, writes a clean daily Markdown file,
    and sends a WhatsApp digest to Subhash.
    """
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    today_str = datetime.now().strftime("%Y%m%d")
    md_file_path = os.path.join(OUTPUT_DIR, f"leads_{today_str}.md")

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("""
    SELECT id, company, niche, location, country, linkedin_url, linkedin_copy, score
    FROM leads
    WHERE linkedin_url IS NOT NULL AND linkedin_url != ''
      AND status IN ('QUALIFIED', 'CONTACTED_EMAIL')
    ORDER BY score DESC
    LIMIT ?
    """, (batch_size,))

    leads = cursor.fetchall()
    if not leads:
        conn.close()
        logger.info("No leads ready for LinkedIn staging.")
        return ""

    # Generate Markdown Content
    lines = [
        f"# 💼 VALIXIS LinkedIn Outreach Staging — {datetime.now().strftime('%B %d, %Y')}",
        "",
        "> High-priority prospects scored for immediate founder connection requests.",
        "",
        "| Company | Niche | Location | Score | Profile Link |",
        "| :--- | :--- | :--- | :--- | :--- |"
    ]

    wa_digest_lines = [
        f"💼 *VALIXIS LINKEDIN STAGING QUEUE*\n📅 *Date:* {datetime.now().strftime('%b %d, %Y')}\n",
        f"Subhash, here are {len(leads)} high-value prospects queued for 1-click connection:\n"
    ]

    for idx, lead in enumerate(leads, 1):
        lines.append(f"| **{lead['company']}** | {lead['niche']} | {lead['location']} | `{lead['score']}/100` | [Open Profile]({lead['linkedin_url']}) |")
        
        wa_digest_lines.append(
            f"{idx}️⃣ *{lead['company']}* ({lead['location']})\n"
            f"🔗 {lead['linkedin_url']}\n"
            f"📝 *Note:* \"{lead['linkedin_copy']}\"\n"
        )

        cursor.execute("UPDATE leads SET status = 'STAGED_LINKEDIN' WHERE id = ?", (lead["id"],))

    lines.append("\n## 📋 1-Click Action Cards\n")
    for idx, lead in enumerate(leads, 1):
        lines.extend([
            f"### {idx}. {lead['company']} ({lead['niche']})",
            f"- **Location:** {lead['location']}, {lead['country']}",
            f"- **LinkedIn URL:** {lead['linkedin_url']}",
            f"- **Copy Connection Note:**",
            f"```text\n{lead['linkedin_copy']}\n```",
            ""
        ])

    conn.commit()
    conn.close()

    # Save Markdown File
    with open(md_file_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    logger.info(f"âœ… LinkedIn batch written to {md_file_path}")

    # Send WhatsApp Summary to Subhash
    wa_digest_lines.append(f"📁 *Staged on server:* `data/linkedin_queue/leads_{today_str}.md`")
    full_wa_message = "\n".join(wa_digest_lines)
    notify_subhash(full_wa_message, title="ðŸ’¼ LINKEDIN OUTREACH READY")

    return md_file_path

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print("Generating LinkedIn Staging Batch...")
    path = generate_linkedin_batch(batch_size=5)
    print(f"Staged at: {path}")
