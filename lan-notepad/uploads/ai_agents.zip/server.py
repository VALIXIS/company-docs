"""
🌐 VALIXIS AI — Ultra-Fast Direct Server with Native Tools & Calendar Links
Direct streaming server using Google Gemini 3.5 Flash-Lite.
Equipped with real email reading, project listing, and 1-click mobile calendar sync.
"""

import asyncio
import json
import os
import sys
from pathlib import Path
import urllib.request
import urllib.error
from dotenv import load_dotenv

load_dotenv()

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import uvicorn

import agent_tools

app = FastAPI(title="Valixis AI", version="2.5")
BASE_DIR = Path(__file__).parent
STATIC_DIR = BASE_DIR / "static"
STATIC_DIR.mkdir(exist_ok=True)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
MODEL_NAME = "gemini-3.5-flash-lite"

# ── Agent System Prompts with Live Capabilities ───────────────────────────────

AGENT_PROMPTS = {
    "orchestrator": {
        "name": "Master Orchestrator",
        "icon": "🧠",
        "description": "Routes tasks & coordinates your business",
        "prompt": """You are the personal AI Chief of Staff for Subhash, founder of Valixis.
You have DIRECT, REAL-TIME ACCESS to:
1. His official inbox (official.valixis@gmail.com).
2. His local projects and repositories across C:/Users/nagas/Documents/PROJECTS and VALIXIS.
3. Generating 1-click mobile Google Calendar add-links.

When Subhash asks about emails, tasks, code, or schedule, be confident, direct, and act on real context.
Never say 'I don't have access to your email or machine'. You are integrated directly into his workstation!"""
    },
    "email": {
        "name": "Email Agent",
        "icon": "📬",
        "description": "Live inbox triage & rapid replies",
        "prompt": """You are the executive communication assistant for Subhash, founder of Valixis.
You have real-time access to his inbox (official.valixis@gmail.com).
Summarize client emails, detect intent, draft responses in his authentic founder voice, and flag urgent priorities.
Never say you cannot see his emails—use the live email context provided."""
    },
    "code": {
        "name": "Code Agent",
        "icon": "🧑‍💻",
        "description": "Review, debug, explain & inspect projects",
        "prompt": """You are a senior principal software engineer for Subhash and Valixis.
You have visibility into his local project directories in Documents.
Review code for performance, security, and scalability, debug errors, and suggest clean architectures."""
    },
    "research": {
        "name": "Research Agent",
        "icon": "🔬",
        "description": "Research anything & learn new skills",
        "prompt": """You are an elite research analyst and learning partner for Subhash.
Synthesize competitor intelligence, explain complex AI and systems engineering concepts, analyze market trends, and cite clear actionable takeaways."""
    },
    "productivity": {
        "name": "Productivity Agent",
        "icon": "📋",
        "description": "Mobile calendar sync & time-blocking",
        "prompt": """You are the tactical productivity chief for Subhash, founder of Valixis.
When planning his day or adding events, ALWAYS format tasks with a direct 1-click Google Calendar link:
Format: [📅 Add to Google Calendar](https://calendar.google.com/calendar/render?action=TEMPLATE&text=EVENT_TITLE&dates=YYYYMMDDTHHMMSS/YYYYMMDDTHHMMSS&details=DETAILS)
This lets Subhash tap the link on his mobile phone to immediately save it into his Google Calendar!
Use MIT (Most Important Task) and strict time-blocks."""
    },
    "writing": {
        "name": "Writing Agent",
        "icon": "✍️",
        "description": "Blog posts, docs, LinkedIn & pitch decks",
        "prompt": """You are an elite copywriter and content strategist for Subhash and Valixis.
Write engaging LinkedIn posts, technical documentation, investor updates, pitch deck slides, and landing page copy. Lead with value and clear hooks."""
    },
    "growth": {
        "name": "Outbound & Growth Agent",
        "icon": "🚀",
        "description": "24/7 Lead Hunter, Multi-Channel Outreach & Pipeline",
        "prompt": """You are the Head of Growth & Outbound Operations for Subhash, founder of Valixis.
You have DIRECT, REAL-TIME ACCESS to:
1. The live outbound leads database across E-Commerce, Clinics, Cafes, Startups, and Real Estate.
2. Cold email outreach status (official.valixis@gmail.com).
3. Cold WhatsApp outreach status (via the local WhatsApp server on port 3001).
4. Staged LinkedIn queues with pre-written connection notes.
5. Jarvis Emergency Voice Caller status.
Report exact numbers, qualify prospects, suggest new niches, and help Subhash close incoming client deals!"""
    }
}

# ── Gemini Direct API Handler with Context Injection ──────────────────────────

def call_gemini(messages: list[dict], system_instruction: str, user_last_query: str) -> str:
    """Injects live tool data if requested, then calls Gemini 3.5 Flash-Lite."""
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL_NAME}:generateContent?key={GEMINI_API_KEY}"
    
    # Check if user is asking about emails or local projects
    q_lower = user_last_query.lower()
    injected_context = ""

    if any(k in q_lower for k in ["email", "inbox", "mail", "unread", "message"]):
        emails = agent_tools.get_recent_emails(count=4)
        injected_context += f"\n\n[LIVE SYSTEM TOOL DATA: RECENT INBOX EMAILS]\n{emails}\n"

    if any(k in q_lower for k in ["github", "repo", "repository", "codebase", "branch"]):
        gh_repos = agent_tools.list_github_repos(count=15)
        injected_context += f"\n\n[LIVE SYSTEM TOOL DATA: SUBHASH GITHUB REPOSITORIES]\n{gh_repos}\n"

    if any(k in q_lower for k in ["project", "local folder", "local project"]):
        projects = agent_tools.list_projects()
        injected_context += f"\n\n[LIVE SYSTEM TOOL DATA: USER LOCAL PROJECTS]\n{projects}\n"

    if any(k in q_lower for k in ["lead", "outbound", "pipeline", "client", "prospect", "growth", "cold email", "cold outreach"]):
        pipeline_data = agent_tools.get_outbound_pipeline_summary()
        injected_context += f"\n\n[LIVE SYSTEM TOOL DATA: OUTBOUND PIPELINE]\n{pipeline_data}\n"

    # Auto-schedule calendar event if requested
    if any(k in q_lower for k in ["schedule", "calendar", "add event", "book meeting", "remind me on"]):
        try:
            import calendar_auto_sync
            from datetime import datetime, timezone, timedelta
            IST = timezone(timedelta(hours=5, minutes=30))
            now_ist = datetime.now(IST)

            # Default: tomorrow at 3:00 PM IST
            target_hour = 15
            target_minute = 0
            if "morning" in q_lower or "10am" in q_lower or "11am" in q_lower:
                target_hour = 10
            elif "afternoon" in q_lower or "2pm" in q_lower:
                target_hour = 14
            elif "3pm" in q_lower:
                target_hour = 15
            elif "4pm" in q_lower:
                target_hour = 16
            elif "evening" in q_lower or "5pm" in q_lower or "6pm" in q_lower:
                target_hour = 18

            event_dt_ist = (now_ist + timedelta(days=1)).replace(hour=target_hour, minute=target_minute, second=0, microsecond=0)
            recipient_email = os.getenv("PERSONAL_EMAIL", "nagasubhash55@gmail.com")
            
            calendar_auto_sync.send_calendar_invite(
                summary=user_last_query[:40],
                start_dt_ist=event_dt_ist,
                duration_minutes=60,
                description=f"Auto-scheduled by Valixis AI Productivity Agent for Subhash: {user_last_query}",
                recipient=recipient_email
            )
            time_display = event_dt_ist.strftime("%A, %b %d at %I:%M %p IST")
            injected_context += f"\n\n[SYSTEM NOTIFICATION: AUTOMATIC CALENDAR INVITE DISPATCHED TO {recipient_email} for {time_display}. Google Calendar will automatically place this into Subhash's mobile calendar in Indian Standard Time (IST)! Confirm this time to Subhash.]\n"
        except Exception as e:
            pass

    contents = []
    for m in messages[:-1]:
        role = "user" if m["role"] == "user" else "model"
        contents.append({
            "role": role,
            "parts": [{"text": m["content"]}]
        })
    
    # Add final user message with any injected real tool context
    final_content = messages[-1]["content"]
    if injected_context:
        final_content += injected_context

    contents.append({
        "role": "user",
        "parts": [{"text": final_content}]
    })
    
    payload = {
        "contents": contents,
        "systemInstruction": {
            "parts": [{"text": system_instruction}]
        },
        "generationConfig": {
            "temperature": 0.7,
            "maxOutputTokens": 2048,
        }
    }
    
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"}
    )
    
    try:
        with urllib.request.urlopen(req, timeout=25) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            candidates = data.get("candidates", [])
            if candidates:
                parts = candidates[0].get("content", {}).get("parts", [])
                if parts:
                    return parts[0].get("text", "")
            return "No response received."
    except urllib.error.HTTPError as e:
        err_msg = e.read().decode("utf-8")
        if e.code == 429:
            return "⚠️ API rate limit reached for this minute. Please wait 30 seconds."
        elif e.code == 503:
            return "⚠️ Gemini service is temporarily busy. Please retry in a few moments."
        return f"API Error ({e.code}): {err_msg}"
    except Exception as e:
        return f"Network Error: {str(e)}"

# ── WebSocket Handler ─────────────────────────────────────────────────────────

@app.websocket("/ws/{session_id}")
async def websocket_endpoint(websocket: WebSocket, session_id: str):
    await websocket.accept()
    current_agent_key = "orchestrator"
    history = []

    try:
        while True:
            raw_data = await websocket.receive_text()
            msg = json.loads(raw_data)
            msg_type = msg.get("type")

            if msg_type == "switch_agent":
                new_key = msg.get("agent_key", "orchestrator")
                if new_key in AGENT_PROMPTS:
                    current_agent_key = new_key
                    history = []
                    await websocket.send_text(json.dumps({
                        "type": "agent_switched",
                        "agent_key": new_key,
                        "agent_name": AGENT_PROMPTS[new_key]["name"],
                    }))
                continue

            if msg_type == "chat":
                user_text = msg.get("text", "").strip()
                if not user_text:
                    continue

                history.append({"role": "user", "content": user_text})
                if len(history) > 10:
                    history = history[-10:]

                await websocket.send_text(json.dumps({"type": "stream_start"}))

                system_prompt = AGENT_PROMPTS[current_agent_key]["prompt"]
                loop = asyncio.get_event_loop()
                full_reply = await loop.run_in_executor(
                    None, call_gemini, list(history), system_prompt, user_text
                )

                history.append({"role": "model", "content": full_reply})

                # Stream response smoothly to UI
                words = full_reply.split(" ")
                chunk_buffer = []
                for idx, w in enumerate(words):
                    chunk_buffer.append(w)
                    if len(chunk_buffer) >= 3 or idx == len(words) - 1:
                        chunk_text = " ".join(chunk_buffer) + (" " if idx < len(words) - 1 else "")
                        await websocket.send_text(json.dumps({
                            "type": "stream_chunk",
                            "text": chunk_text
                        }))
                        chunk_buffer = []
                        await asyncio.sleep(0.015)

                await websocket.send_text(json.dumps({
                    "type": "stream_end",
                    "full_text": full_reply
                }))

    except WebSocketDisconnect:
        pass
    except Exception as e:
        try:
            await websocket.send_text(json.dumps({"type": "error", "text": str(e)}))
        except:
            pass

@app.get("/agents")
def list_agents():
    return [
        {"key": k, "name": v["name"], "icon": v["icon"], "description": v["description"]}
        for k, v in AGENT_PROMPTS.items()
    ]

@app.get("/")
def serve_ui():
    return FileResponse(STATIC_DIR / "index.html")

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

if __name__ == "__main__":
    uvicorn.run("server:app", host="0.0.0.0", port=8000, log_level="info")
