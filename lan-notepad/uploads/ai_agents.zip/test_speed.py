import asyncio
import os
import time
from dotenv import load_dotenv

load_dotenv()

from google.antigravity import Agent, LocalAgentConfig

async def test():
    t0 = time.time()
    print("Connecting to agent...")
    config = LocalAgentConfig(model="gemini-3.1-flash-lite")
    async with Agent(config) as agent:
        print(f"Agent session opened in {time.time() - t0:.2f}s")
        t1 = time.time()
        print("Sending message...")
        response = await agent.chat("Say hello in three words")
        print(f"Chat response object received in {time.time() - t1:.2f}s. Streaming chunks:")
        full = ""
        async for chunk in response:
            print(chunk, end="", flush=True)
            full += chunk
        print(f"\nCompleted stream in {time.time() - t1:.2f}s. Total: {full.strip()}")

if __name__ == "__main__":
    asyncio.run(test())
