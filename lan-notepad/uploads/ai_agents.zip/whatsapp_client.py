"""
ðŸ’¬ WhatsApp Client Bridge
Connects directly to the local WhatsApp Server running on port 3001
Endpoint: http://localhost:3001/send-task-alert
"""

import os
import json
import logging
import requests
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger("WhatsAppClient")
logger.setLevel(logging.INFO)

WHATSAPP_URL = os.getenv("WHATSAPP_LOCAL_SERVICE_URL", "http://localhost:3001")
ALERT_ENDPOINT = f"{WHATSAPP_URL.rstrip('/')}/send-task-alert"
SUBHASH_PHONE = os.getenv("ALERT_PHONE", "+919603416707")

def format_phone_number(raw_phone: str) -> str:
    """Cleans phone numbers into international digits format."""
    digits = "".join(filter(str.isdigit, raw_phone))
    # If 10 digits without country code, default to India (+91)
    if len(digits) == 10:
        digits = "91" + digits
    return digits

def send_whatsapp_message(phone: str, message: str, title: str = "VALIXIS OUTBOUND") -> bool:
    """
    Sends a WhatsApp message via the server on port 3001.
    Compatible with endpoints expecting: phone/number, task/message/text.
    """
    clean_phone = format_phone_number(phone)
    formatted_msg = f"*{title}*\n\n{message}" if title else message

    payload = {
        "phone": clean_phone,
        "number": clean_phone,
        "recipient": clean_phone,
        "task": formatted_msg,
        "message": formatted_msg,
        "text": formatted_msg
    }

    try:
        response = requests.post(
            ALERT_ENDPOINT,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=8
        )
        if response.status_code in [200, 201]:
            logger.info(f"âœ… WhatsApp sent to {clean_phone} via {ALERT_ENDPOINT}")
            return True
        else:
            logger.warning(f"âš ï¸  WhatsApp server returned status {response.status_code}: {response.text}")
            return False
    except requests.exceptions.RequestException as e:
        logger.error(f"â Œ Failed to connect to WhatsApp server at {ALERT_ENDPOINT}: {e}")
        return False

def notify_subhash(message: str, title: str = "ðŸš¨ VALIXIS JARVIS ALERT") -> bool:
    """Directly notifies Subhash on his personal WhatsApp."""
    return send_whatsapp_message(phone=SUBHASH_PHONE, message=message, title=title)

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print(f"Testing WhatsApp bridge to {ALERT_ENDPOINT}...")
    success = notify_subhash("Test alert from VALIXIS Outbound Lead Engine. The bridge is operational!")
    print(f"Result: {'Success' if success else 'Server unreachable (ensure old laptop server is up)'}")
