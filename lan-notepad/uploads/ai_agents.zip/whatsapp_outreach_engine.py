"""
ðŸ’¬ Autonomous WhatsApp Cold Outreach Engine
Dispatches personalized cold WhatsApp messages to qualified leads
using Subhash's WhatsApp server active on port 3001 (/send-task-alert).
"""

import os
import time
import sqlite3
import logging
from dotenv import load_dotenv
from whatsapp_client import send_whatsapp_message, format_phone_number

load_dotenv()

logger = logging.getLogger("WhatsAppOutreachEngine")
logger.setLevel(logging.INFO)

DB_PATH = os.path.join(os.path.dirname(__file__), "data", "leads.db")

def dispatch_whatsapp_batch(batch_size: int = 3, cooldown_seconds: int = 15) -> int:
    """
    Finds qualified leads with valid phone numbers and sends personalized WhatsApp outreach.
    """
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("""
    SELECT id, company, phone, whatsapp_copy, location
    FROM leads
    WHERE phone IS NOT NULL AND phone != ''
      AND whatsapp_copy IS NOT NULL AND whatsapp_copy != ''
      AND status IN ('QUALIFIED', 'CONTACTED_EMAIL')
    LIMIT ?
    """, (batch_size,))

    leads = cursor.fetchall()
    if not leads:
        conn.close()
        logger.info("No qualified leads ready for WhatsApp outreach.")
        return 0

    sent_count = 0
    for lead in leads:
        lead_id = lead["id"]
        phone = lead["phone"]
        msg = lead["whatsapp_copy"]
        company = lead["company"]

        logger.info(f"Sending WhatsApp cold message to {company} ({phone})...")

        # Skip dummy test numbers ending in 01xx
        if "55501" in phone or phone.startswith("+999"):
            logger.info(f"[SIMULATED OUTREACH] Successfully verified WhatsApp payload for {company} ({phone})")
            success = True
        else:
            success = send_whatsapp_message(phone=phone, message=msg, title="")

        if success:
            cursor.execute("""
            UPDATE leads
            SET status = 'CONTACTED_WA', updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """, (lead_id,))
            conn.commit()
            sent_count += 1
            time.sleep(cooldown_seconds)

    conn.close()
    return sent_count

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print("Testing WhatsApp Cold Outreach Engine...")
    count = dispatch_whatsapp_batch(batch_size=2, cooldown_seconds=2)
    print(f"Dispatched {count} WhatsApp messages.")
